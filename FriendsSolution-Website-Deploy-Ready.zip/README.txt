FRIENDSSOLUTION — DEPLOY-READY WEBSITE

PACKAGE CONTENTS
- index.html
- assets/friends-solution-logo.png
- assets/friendssolution-cover.png

The updated page includes the FriendsSolution product catalogue and the contact
email friendssolution99@gmail.com. Image paths have been corrected.

DEPLOY TO RENDER (STATIC SITE)
1. Extract this ZIP.
2. Put index.html and the assets folder in the root of your GitHub repository.
3. Commit and push the files to the branch selected by your Render service (usually main).
4. In Render, open your Static Site.
5. Confirm:
   - Branch: main (or your repository's deployment branch)
   - Root Directory: blank, unless the site files are inside a subfolder
   - Build Command: blank
   - Publish Directory: .
6. Trigger Manual Deploy > Deploy latest commit, if it does not deploy automatically.
7. Open the service URL shown at the top of the Render service page.

DEPLOY TO GITHUB PAGES
1. Extract this ZIP.
2. Upload index.html and the complete assets folder to the repository root.
3. Commit the files.
4. Open repository Settings > Pages.
5. Select Deploy from a branch, branch main, folder /(root), then Save.
6. Open the published Pages URL shown there.

NOTES
- Keep the assets folder beside index.html.
- This is a static information/catalogue website. The app descriptions are not
  themselves working login, messaging, marketplace, or database services.
- Review the contact details and product launch links before sharing publicly.
