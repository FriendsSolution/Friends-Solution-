FRIENDSSOLUTION ACTIVE WEBSITE — INSTALLATION

FILES
- index.html
- assets/friends-solution-banner.jpg
- assets/friends-solution-logo.jpg

UPLOAD TO GITHUB PAGES
1. Download and extract this ZIP on your phone or computer.
2. Open your public GitHub repository: Friends-Solution-
3. Upload index.html and the entire assets folder into the repository ROOT (not inside another folder).
4. Commit directly to main.
5. Open repository Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch, branch main, folder /(root), and Save.
7. Wait a few minutes, then open your GitHub Pages URL and refresh.

ACTIVE BROWSER TOOLS
- Basic calculator: add, subtract, multiply, divide and percentage.
- GST calculator: GST estimate and total.
- Word and character counter.
- Unit converter: km/miles, kg/pounds, cm/inches, Celsius/Fahrenheit.
- Text case converter: upper, lower, title and sentence case.
- QR code maker: requires internet access to load the QRCode.js library from cdnjs.
- Search cards, share website button, email contact links.

CONTACT
friendssolution99@gmail.com

IMPORTANT
- Website is static; it has no login, database, payments, newsletter or cloud storage.
- The calculator/text tools run locally in your browser. QR generation uses a third-party CDN.
- Review the Friends MAP link and repository/site URL before public promotion, in case your GitHub username/repository names differ.
- GitHub upload should include index.html and assets folder side by side.
